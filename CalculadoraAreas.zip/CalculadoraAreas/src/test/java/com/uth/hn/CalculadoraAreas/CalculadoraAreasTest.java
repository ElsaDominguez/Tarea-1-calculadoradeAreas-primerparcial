package com.uth.hn.CalculadoraAreas;

import org.junit.Test;

public class CalculadoraAreasTest {
    // Define tus métodos de prueba aquí



@Test
public void testAreaCirculo() {
    assertEquals(12.566370614359172, calcularAreaCirculo(2), 0.01);
    assertEquals(28.274333882308138, calcularAreaCirculo(3), 0.01);
}

private void assertEquals(double expected, Object calcularAreaCirculo, double delta) {
	// TODO Auto-generated method stub
	
}

private Object calcularAreaCirculo(int i) {
	// TODO Auto-generated method stub
	return null;
}

@Test
public void testAreaCuadrado() {
    assertEquals(16.0, calcularAreaCuadrado(4), 0.01);
    assertEquals(25.0, calcularAreaCuadrado(5), 0.01);
}

private Object calcularAreaCuadrado(double d) {
	// TODO Auto-generated method stub
	return null;
}

@Test
public void testAreaRectangulo() {
    assertEquals(18.0, calcularAreaRectangulo(3, 6), 0.01);
    assertEquals(48.0, calcularAreaRectangulo(8, 6), 0.01);
}

private Object calcularAreaRectangulo(int i, int j) {
	// TODO Auto-generated method stub
	return null;
}

@Test
public void testAreaTriangulo() {
    assertEquals(6.0, calcularAreaTriangulo(3, 4), 0.01);
    assertEquals(15.0, calcularAreaTriangulo(5, 6), 0.01);
}

private Object calcularAreaTriangulo(int i, int j) {
	// TODO Auto-generated method stub
	return null;
}
@Test
public void testAreaCirculoConRadioCero() {
    assertEquals(0.0, calcularAreaCirculo(0), 0.01);
}

@Test
public void testAreaCuadradoConLadoNegativo() {
    assertEquals(0.0, calcularAreaCuadrado(-4), 0.01);
}

@Test
public void testAreaRectanguloConBaseYAlturaCero() {
    assertEquals(0.0, calcularAreaRectangulo(0, 0), 0.01);
}

@Test
public void testAreaTrianguloConBaseCero() {
    assertEquals(0.0, calcularAreaTriangulo(0, 5), 0.01);
}

@Test
public void testAreaTrianguloConAlturaCero() {
    assertEquals(0.0, calcularAreaTriangulo(4, 0), 0.01);
}

@Test
public void testAreaTrianguloConBaseYAlturaNegativas() {
    assertEquals(0.0, calcularAreaTriangulo(-4, -5), 0.01);
}
@Test
public void testAreaCirculoConRadioDecimales() {
    assertEquals(12.566, calcularAreaCuadrado(2.0), 0.01);
}

@Test
public void testAreaCuadradoConLadoDecimal() {
    assertEquals(2.25, calcularAreaCuadrado(1.5), 0.01);
}


}



